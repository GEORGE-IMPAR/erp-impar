<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
date_default_timezone_set('America/Sao_Paulo');

function tv_out($arr, $code=200){ http_response_code($code); echo json_encode($arr, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT); exit; }
function tv_is_list($arr){ if(!is_array($arr)) return false; $i=0; foreach($arr as $k=>$v){ if($k !== $i++) return false; } return true; }
function tv_read_json($file){ if(!$file || !is_file($file)) return null; $txt=file_get_contents($file); if($txt===false || trim($txt)==='') return null; $j=json_decode($txt,true); return is_array($j)?$j:null; }
function tv_meta($file){ return ['arquivo'=>$file,'existe'=>is_file((string)$file),'tamanho'=>is_file((string)$file)?filesize($file):null,'mtime'=>is_file((string)$file)?date('c',filemtime($file)):null]; }
function tv_pick($arr,$keys,$default=''){ if(!is_array($arr)) return $default; foreach($keys as $k){ if(array_key_exists($k,$arr) && $arr[$k]!==null && $arr[$k]!=='') return $arr[$k]; } return $default; }
function tv_num($v,$default=0){ if($v===null || $v==='') return $default; if(is_numeric($v)) return (float)$v; $s=str_replace('%','',(string)$v); $s=preg_replace('/[^\d,\.\-]+/','',$s); if(strpos($s,',')!==false && strpos($s,'.')!==false){ $s=str_replace('.','',$s); $s=str_replace(',','.',$s); } else { $s=str_replace(',','.',$s); } $n=(float)$s; return is_finite($n)?$n:$default; }
function tv_pick_num($arr,$keys,$default=0){ if(!is_array($arr)) return $default; foreach($keys as $k){ if(array_key_exists($k,$arr) && $arr[$k]!==null && $arr[$k]!=='') return tv_num($arr[$k],$default); } return $default; }
function tv_norm_txt($s){ $s=trim((string)$s); if($s==='') return ''; $x=@iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s); if($x!==false) $s=$x; $s=strtoupper($s); $s=preg_replace('/[^A-Z0-9]+/',' ',$s); return trim(preg_replace('/\s+/',' ',$s)); }
function tv_digits($s){ return preg_replace('/\D+/','',(string)$s); }
function tv_norm_id($v){ $d=tv_digits($v); return $d===''?'':str_pad(substr($d,-3),3,'0',STR_PAD_LEFT); }
function tv_ts($v){ if(!$v) return null; $ts=strtotime((string)$v); return $ts?$ts:null; }
function tv_dias_desde($v){ $ts=tv_ts($v); if(!$ts) return null; $hoje=strtotime(date('Y-m-d 12:00:00')); $dia=strtotime(date('Y-m-d 12:00:00',$ts)); return (int)floor(($hoje-$dia)/86400); }
function tv_ymd(){ $d=$_GET['data'] ?? ''; return preg_match('/^\d{4}-\d{2}-\d{2}$/',$d)?$d:''; }
function tv_latest_activity_file(){ $files=tv_glob(tv_agenda_dir(),'atividade_dia_*.json'); if(!$files) return null; usort($files,function($a,$b){return filemtime($b)<=>filemtime($a);}); return $files[0]; }
function tv_date_from_activity_file($file){ if(preg_match('/atividade_dia_(\d{4}-\d{2}-\d{2})\.json$/',basename((string)$file),$m)) return $m[1]; return ''; }
function tv_monday($date=null){ $ts=$date?strtotime($date):time(); if(!$ts) $ts=time(); return date('Y-m-d',strtotime('monday this week',$ts)); }
function tv_week(){ $s=$_GET['semana'] ?? tv_monday(); return preg_match('/^\d{4}-\d{2}-\d{2}$/',$s)?$s:tv_monday(); }
function tv_first($cands){ foreach($cands as $f){ if(is_file($f)) return $f; } return null; }
function tv_glob($dir,$pattern){ if(!is_dir($dir)) return []; $g=glob(rtrim($dir,'/').'/'.$pattern); return is_array($g)?$g:[]; }
function tv_www(){ return dirname(__DIR__,2); } // instalado em /www/api/tv
function tv_api(){ return tv_www().'/api'; }
function tv_storage(){ return tv_www().'/storage/data'; }
function tv_agenda_dir(){ return tv_api().'/agenda/data'; }
function tv_format_br($v){ $ts=tv_ts($v); return $ts?date('d/m/Y H:i',$ts):(string)$v; }

function tv_flatten_atividades($data){
  $out=[]; if(!is_array($data)) return $out; $c=[];
  foreach(['atividades','tarefas','tasks','linhas','items'] as $k){ if(isset($data[$k]) && is_array($data[$k])) $c[]=$data[$k]; }
  if(isset($data['data']) && is_array($data['data'])) foreach(['atividades','tarefas','tasks','linhas','items'] as $k){ if(isset($data['data'][$k]) && is_array($data['data'][$k])) $c[]=$data['data'][$k]; }
  if(!$c){ foreach($data as $v){ if(is_array($v) && (isset($v['atividade'])||isset($v['descricao'])||isset($v['nome'])||isset($v['titulo']))){ $c[]=$data; break; } } }
  $walk=function($arr) use (&$walk,&$out){ foreach($arr as $it){ if(!is_array($it)) continue; if(isset($it['atividade'])||isset($it['descricao'])||isset($it['nome'])||isset($it['titulo'])) $out[]=$it; foreach(['filhos','children','subatividades','subtarefas','itens','atividades'] as $ck){ if(isset($it[$ck]) && is_array($it[$ck])) $walk($it[$ck]); } } };
  foreach($c as $arr) $walk($arr); return $out;
}

function tv_resumo_cronograma($data,$file=''){
  $ats=tv_flatten_atividades($data); $total=0; $somaDias=0; $pondPrev=0; $pondReal=0; $concl=0; $and=0; $atr=0; $nao=0; $inicio=null; $fim=null;
  foreach($ats as $a){
    $nome=trim((string)tv_pick($a,['atividade','descricao','nome','titulo'],'')); if($nome==='') continue; $total++;
    $dias=tv_pick_num($a,['dias','duracao','duração','duration'],1); if($dias<=0) $dias=1;
    $prev=tv_pick_num($a,['previsto','percentualPrevisto','percentual_previsto','%previsto','planejado','prev'],0);
    $real=tv_pick_num($a,['real','percentualReal','percentual_real','%real','executado','percentual','progresso'],0);
    $somaDias += $dias; $pondPrev += $dias*$prev; $pondReal += $dias*$real;
    if($real>=100) $concl++; elseif($real>0) $and++; else $nao++;
    if($prev>$real && $prev>=100 && $real<100) $atr++;
    $i=tv_pick($a,['inicio','dataInicio','data_inicio','start'],''); $f=tv_pick($a,['fim','dataFim','data_fim','end'],'');
    if($i && (!$inicio || strcmp($i,$inicio)<0)) $inicio=$i; if($f && (!$fim || strcmp($f,$fim)>0)) $fim=$f;
  }
  $prevTotal=$somaDias>0?round($pondPrev/$somaDias,2):tv_pick_num($data,['percentual_previsto','previsto','previstoTotal','previsto_total'],0);
  $realTotal=$somaDias>0?round($pondReal/$somaDias,2):tv_pick_num($data,['percentual_realizado','realizado','real','realTotal','real_total'],0);
  $up=tv_pick($data,['ultimaAtualizacao','ultima_atualizacao','updated_at','updatedAt','dataAtualizacao'],is_file($file)?date('c',filemtime($file)):'');
  return [
    'id'=>tv_norm_id(tv_pick($data,['id','obra_id','codigo','codigo_obra'],basename($file))),
    'obra'=>tv_pick($data,['nome','obra','projeto','titulo'],''),
    'coordenador'=>tv_pick($data,['coordenador','responsavel','responsável'],''),
    'inicio'=>$inicio ?: tv_pick($data,['inicio','data_inicio','inicioPrevisto'],''),
    'fim'=>$fim ?: tv_pick($data,['fim','data_fim','fimPrevisto'],''),
    'dias'=>$somaDias,
    'previsto'=>$prevTotal,
    'realizado'=>$realTotal,
    'status'=>$realTotal>=100?'Concluído':($realTotal>=$prevTotal?'Em andamento':'Atrasado'),
    'farol'=>$realTotal>=100?'verde':($realTotal>=$prevTotal?'verde':'vermelho'),
    'ultima_atualizacao'=>$up,
    'dias_sem_atualizacao'=>tv_dias_desde($up),
    'atividades'=>['total'=>$total,'concluidas'=>$concl,'andamento'=>$and,'atrasadas'=>$atr,'nao_iniciadas'=>$nao]
  ];
}

function tv_cronogramas_ativos(){
  $files=tv_glob(tv_storage(),'obra_*.json'); sort($files,SORT_NATURAL); $items=[];
  foreach($files as $file){ $j=tv_read_json($file); if(!$j) continue; $r=tv_resumo_cronograma($j,$file); if(!$r['id'] || !$r['obra']) continue; if(($r['atividades']['total']??0)<=0 && filesize($file)<1500) continue; if(($r['realizado']??0)>=100) continue; $r['arquivo']=basename($file); $items[]=$r; }
  return $items;
}

function tv_file_projetos(){ $c=[__DIR__.'/data/projetos.json', tv_api().'/tv/data/projetos.json', tv_www().'/tv/data/projetos.json']; return tv_first($c); }
function tv_list_tv_projetos(){ $file=tv_file_projetos(); $j=tv_read_json($file); $list=[]; if(is_array($j)){ if(isset($j['data']['projetos'])&&is_array($j['data']['projetos'])) $list=$j['data']['projetos']; elseif(isset($j['projetos'])&&is_array($j['projetos'])) $list=$j['projetos']; elseif(tv_is_list($j)) $list=$j; } return [$file,$list]; }

function tv_last_status_from_item($p){
  $hist=[]; foreach(['historico','histórico','status_historico','statusHistorico','atualizacoes','atualizações','updates'] as $k){ if(isset($p[$k]) && is_array($p[$k])){ $hist=$p[$k]; break; } }
  if($hist){ usort($hist,function($a,$b){ return tv_ts(tv_pick($b,['data','data_atualizacao','created_at','updated_at'],'')) <=> tv_ts(tv_pick($a,['data','data_atualizacao','created_at','updated_at'],'')); }); $h=$hist[0]; return [
    'ultimo_status'=>tv_pick($h,['status','status_atual','texto','mensagem','descricao','observacao','observação'],''),
    'usuario'=>tv_pick($h,['usuario','usuario_atualizacao','autor','nome'],''),
    'data'=>tv_pick($h,['data','data_atualizacao','created_at','updated_at'],''),
    'raw'=>$h
  ]; }
  return [
    'ultimo_status'=>tv_pick($p,['status_atual','statusAtual','status','resumo','descricao','observacao','observação','texto','mensagem'],''),
    'usuario'=>tv_pick($p,['usuario_atualizacao','usuario','autor','atualizado_por'],''),
    'data'=>tv_pick($p,['data_atualizacao','dataAtualizacao','ultimaAtualizacao','ultima_atualizacao','updated_at','updatedAt'],''),
    'raw'=>null
  ];
}

function tv_status_obras_ativas(){
  $ativas=tv_cronogramas_ativos(); list($file,$list)=tv_list_tv_projetos(); $byId=[]; $byNome=[];
  foreach($list as $p){ if(!is_array($p)) continue; $id=tv_norm_id(tv_pick($p,['id','obra_id','codigo'],'')); $nome=tv_pick($p,['nome','obra','projeto','titulo'],''); if($id) $byId[$id]=$p; if($nome) $byNome[tv_norm_txt($nome)]=$p; }
  $out=[]; foreach($ativas as $r){ $id=$r['id']; $nome=$r['obra']; $p=isset($byId[$id])?$byId[$id]:(isset($byNome[tv_norm_txt($nome)])?$byNome[tv_norm_txt($nome)]:null); $last=$p?tv_last_status_from_item($p):['ultimo_status'=>'','usuario'=>'','data'=>'','raw'=>null]; $out[]=[
    'id'=>$id,'obra'=>$nome,'coordenador'=>$p?tv_pick($p,['coordenador','responsavel'],$r['coordenador']):$r['coordenador'],
    'farol'=>$p?tv_pick($p,['farol','status_cor','cor'],''):'', 'encontrado_na_tv'=>(bool)$p,
    'ultimo_status'=>$last['ultimo_status'], 'usuario'=>$last['usuario'], 'data'=>$last['data'], 'data_formatada'=>tv_format_br($last['data']), 'dias_sem_atualizacao'=>tv_dias_desde($last['data'])
  ]; }
  return ['fonte'=>tv_meta($file),'total_obras_ativas'=>count($out),'obras'=>$out];
}

function tv_atividade_dia_resumo($date=''){
  $dir=tv_agenda_dir();
  $file = $date ? ($dir.'/atividade_dia_'.$date.'.json') : tv_latest_activity_file();
  $date = $date ?: tv_date_from_activity_file($file);
  $data=tv_read_json($file);
  if(!$data) return ['ok'=>true,'data'=>$date,'encontrado'=>false,'fonte'=>tv_meta($file),'total_colaboradores'=>0,'equipes'=>[],'resumo'=>['atividades'=>0,'viagens'=>0,'finalizadas'=>0,'pendentes'=>0]];

  $items=[];
  if(isset($data['atividades']) && is_array($data['atividades'])) $items=$data['atividades'];
  elseif(isset($data['data']['atividades']) && is_array($data['data']['atividades'])) $items=$data['data']['atividades'];
  elseif(isset($data['rows']) && is_array($data['rows'])) $items=$data['rows'];
  elseif(tv_is_list($data)) $items=$data;

  $linhas=[]; $por=[];
  foreach($items as $item){
    if(!is_array($item)) continue;
    $nome=trim((string)tv_pick($item,['colaborador','nome','responsavel','responsável'],'SEM NOME')) ?: 'SEM NOME';
    $execs=[];
    foreach(['execucoes','execuções','executado','planejado','alocacoes','alocações'] as $k){
      if(isset($item[$k]) && is_array($item[$k])){ $execs = tv_is_list($item[$k]) ? $item[$k] : [$item[$k]]; break; }
    }
    if(!$execs) $execs=[$item];
    foreach($execs as $e){
      if(!is_array($e)) $e=[];
      $obra=tv_pick($e,['obra','obraNome','nomeObra','local','obraLocal'],tv_pick($item,['obra','obraNome','nomeObra','local','obraLocal'],''));
      $ativ=tv_pick($e,['atividade','atividadeNome','nomeAtividade','descricao','atividadeTexto'],tv_pick($item,['atividade','atividadeNome','nomeAtividade','descricao','planejado_atividade','atividadeTexto'],''));
      $row=[
        'nome'=>$nome,
        'obra'=>$obra ?: 'OBRA NÃO INFORMADA',
        'atividade'=>$ativ ?: 'Atividade não informada',
        'placa'=>tv_pick($e,['placa','carro'],tv_pick($item,['placa','carro'],'')),
        'percentual'=>tv_pick_num($e,['percentual','realizado','execucao','execução'],tv_pick_num($item,['percentual','realizado','execucao','execução'],0)),
        'status'=>(!empty($e['finalizado'])||!empty($item['finalizado'])?'finalizado':(!empty($e['cancelado'])||!empty($item['cancelado'])?'cancelado':'pendente')),
        'viagem'=>(bool)(($item['viagem']??false)||($e['viagem']??false)),
        'motivo'=>tv_pick($e,['motivo','observacao','observação'],tv_pick($item,['motivo','observacao','observação'],'')),
        'horas'=>tv_pick_num($e,['horas','qtdHoras'],tv_pick_num($item,['horas','qtdHoras'],8))
      ];
      $linhas[]=$row; $por[$nome][]=$row;
    }
  }
  ksort($por,SORT_NATURAL|SORT_FLAG_CASE);
  $viagens=0; $fin=0; $pend=0; foreach($linhas as $r){ if($r['viagem'])$viagens++; if($r['status']==='finalizado')$fin++; if($r['status']==='pendente')$pend++; }
  return ['ok'=>true,'data'=>$date,'encontrado'=>true,'fonte'=>tv_meta($file),'total_colaboradores'=>count($por),'equipes'=>$linhas,'por_colaborador'=>$por,'resumo'=>['atividades'=>count($linhas),'viagens'=>$viagens,'finalizadas'=>$fin,'pendentes'=>$pend]];
}

function tv_agenda_semanal_resumo($semana=''){
  $dir=tv_agenda_dir();
  $c=[];
  if($semana){
    $c=[
      $dir.'/agenda_semanal_historico_'.$semana.'.json', $dir.'/agenda_semanal_'.$semana.'.json', $dir.'/agenda_'.$semana.'.json',
      $dir.'/agenda_semanal_historico-'.$semana.'.json', $dir.'/agenda_semanal-'.$semana.'.json'
    ];
  }
  $c=array_merge($c,[$dir.'/agenda_semanal_historico.json',$dir.'/agenda_semanal.json',$dir.'/agenda.json']);
  $file=tv_first($c);
  if(!$file){ $files=array_merge(tv_glob($dir,'agenda_semanal*.json'),tv_glob($dir,'agenda_*.json')); usort($files,function($a,$b){return filemtime($b)<=>filemtime($a);}); $file=$files[0]??null; }
  $data=tv_read_json($file);
  if(!$data) return ['ok'=>true,'semana'=>$semana,'encontrado'=>false,'fonte'=>tv_meta($file),'candidatos'=>$c,'colaboradores'=>[],'linhas_impressao'=>[],'resumo'=>['colaboradores'=>0,'alocacoes'=>0,'viagens'=>0,'horas'=>0]];

  $semana = $data['semana'] ?? $semana;
  $colabs = $data['colaboradores'] ?? ($data['data']['colaboradores'] ?? []);
  $agenda=$data['agenda'] ?? ($data['data']['agenda'] ?? null);
  if(!$agenda) $agenda=$data['alocacoes'] ?? ($data['alocações'] ?? ($data['data']['alocacoes'] ?? null));
  if(!$agenda && isset($data['data']) && is_array($data['data'])) $agenda=$data['data'];
  if(!$agenda) $agenda=$data;

  $linhas=[];
  $add=function($col,$dia,$a) use (&$linhas){
    if(!is_array($a)) return;
    $obra=tv_pick($a,['obra','obraNome','nomeObra','obraLocal','local','tipoAvulsa'],'');
    $ativ=tv_pick($a,['atividade','atividadeNome','nomeAtividade','descricao','atividadeTexto'],'');
    $viagem=(bool)($a['viagem']??false);
    if($obra==='' && $ativ==='' && !$viagem) return;
    $linhas[]=[
      'colaborador'=>$col?:tv_pick($a,['colaborador','nome'],'SEM NOME'),
      'dia'=>$dia,
      'obra'=>$obra?:'SEM OBRA',
      'atividade'=>$ativ?:'Sem atividade',
      'horas'=>tv_pick_num($a,['horas','qtdHoras'],8),
      'viagem'=>$viagem,
      'obra_id'=>$a['obraId']??($a['obra_id']??null),
      'atividade_id'=>$a['atividadeId']??($a['atividade_id']??null)
    ];
  };

  if(is_array($agenda)){
    foreach($agenda as $col=>$obj){
      if(!is_array($obj)) continue;
      // Estrutura oficial: agenda[NOME].dias[0..4].alocacoes[]
      if(isset($obj['dias']) && is_array($obj['dias'])){
        foreach($obj['dias'] as $dia=>$diaObj){
          if(is_array($diaObj) && isset($diaObj['alocacoes']) && is_array($diaObj['alocacoes'])) foreach($diaObj['alocacoes'] as $a) $add((string)$col,$dia,$a);
          elseif(is_array($diaObj) && tv_is_list($diaObj)) foreach($diaObj as $a) $add((string)$col,$dia,$a);
          elseif(is_array($diaObj)) $add((string)$col,$dia,$diaObj);
        }
        continue;
      }
      // Estrutura alternativa: agenda[NOME][dia]
      if(!isset($obj['colaborador']) && !isset($obj['obra']) && !isset($obj['atividade'])){
        foreach($obj as $dia=>$alocs){
          if(is_array($alocs) && isset($alocs['alocacoes']) && is_array($alocs['alocacoes'])) foreach($alocs['alocacoes'] as $a) $add(is_string($col)?$col:'',$dia,$a);
          elseif(is_array($alocs) && tv_is_list($alocs)) foreach($alocs as $a) $add(is_string($col)?$col:'',$dia,$a);
          elseif(is_array($alocs)) $add(is_string($col)?$col:'',$dia,$alocs);
        }
      } else $add('', '', $obj);
    }
  }

  if(!$linhas && isset($data['resumo']) && is_array($data['resumo'])) foreach($data['resumo'] as $r) if(is_array($r)) $linhas[]=['colaborador'=>tv_pick($r,['colaborador','nome'],'SEM NOME'),'dia'=>$r['dia']??'','obra'=>tv_pick($r,['obra','obraNome'],'SEM OBRA'),'atividade'=>tv_pick($r,['atividade','descricao'],'Sem atividade'),'horas'=>tv_pick_num($r,['horas'],8),'viagem'=>(bool)($r['viagem']??false)];
  if(!$linhas && isset($data['linhas']) && is_array($data['linhas'])) foreach($data['linhas'] as $r) if(is_array($r)) $linhas[]=['colaborador'=>tv_pick($r,['colaborador','nome'],'SEM NOME'),'dia'=>$r['dia']??'','obra'=>tv_pick($r,['obra','obraNome'],'SEM OBRA'),'atividade'=>tv_pick($r,['atividade','descricao'],'Sem atividade'),'horas'=>tv_pick_num($r,['horas'],8),'viagem'=>(bool)($r['viagem']??false)];

  $por=[]; $horas=0; $viagens=0; foreach($linhas as $r){ $por[$r['colaborador']][]=$r; $horas+=(float)($r['horas']??0); if(!empty($r['viagem']))$viagens++; }
  if(!$por && is_array($colabs)){ foreach($colabs as $c){ $n=is_array($c)?tv_pick($c,['nome','colaborador'],''):(string)$c; if($n) $por[$n]=[]; } }
  ksort($por,SORT_NATURAL|SORT_FLAG_CASE);
  $diaMatch=function($dia,$opts){ $d=tv_norm_txt($dia); foreach($opts as $o){ if($d===tv_norm_txt($o) || (string)$dia===(string)$o) return true; } return false; };
  $cols=[]; foreach($por as $nome=>$rows){ $cols[]=['nome'=>$nome,'segunda'=>array_values(array_filter($rows,function($x) use ($diaMatch){return $diaMatch($x['dia'],['0','segunda','segunda-feira','seg']);})),'terca'=>array_values(array_filter($rows,function($x) use ($diaMatch){return $diaMatch($x['dia'],['1','terca','terça','terça-feira','ter']);})),'quarta'=>array_values(array_filter($rows,function($x) use ($diaMatch){return $diaMatch($x['dia'],['2','quarta','quarta-feira','qua']);})),'quinta'=>array_values(array_filter($rows,function($x) use ($diaMatch){return $diaMatch($x['dia'],['3','quinta','quinta-feira','qui']);})),'sexta'=>array_values(array_filter($rows,function($x) use ($diaMatch){return $diaMatch($x['dia'],['4','sexta','sexta-feira','sex']);})),'alocacoes'=>$rows]; }
  return ['ok'=>true,'semana'=>$semana,'encontrado'=>true,'fonte'=>tv_meta($file),'colaboradores'=>$cols,'linhas_impressao'=>$linhas,'por_colaborador'=>$por,'resumo'=>['colaboradores'=>count($por),'alocacoes'=>count($linhas),'viagens'=>$viagens,'horas'=>$horas]];
}

function tv_qpi1_mes(){
  $files=tv_glob(tv_agenda_dir(),'atividade_dia_*.json');
  $ym=date('Y-m'); $scores=[];
  foreach($files as $file){
    $data=tv_date_from_activity_file($file); if(!$data || substr($data,0,7)!==$ym) continue;
    $ts=filemtime($file); if(!$ts) continue;
    $diaAtiv=strtotime($data.' 12:00:00'); if(!$diaAtiv) continue;
    $esperado=date('Y-m-d',strtotime('-1 day',$diaAtiv));
    $diaGerado=date('Y-m-d',$ts);
    if($diaGerado!==$esperado) $score=0;
    else { $min=(int)date('H',$ts)*60+(int)date('i',$ts); $score=($min<=960?100:($min<=1020?50:0)); }
    $scores[]=['data'=>$data,'score'=>$score,'gerado_em'=>date('c',$ts),'arquivo'=>basename($file)];
  }
  usort($scores,function($a,$b){return strcmp($a['data'],$b['data']);});
  $media=count($scores)?round(array_sum(array_column($scores,'score'))/count($scores),2):0;
  return ['score'=>$media,'dias'=>count($scores),'ultima'=>end($scores)?:null,'itens'=>$scores];
}

function tv_combustivel_mes(){
  $file=tv_www().'/api/rh/combustivel/data/combustivel.json'; $j=tv_read_json($file); $ym=date('Y-m'); $total=0; $l=[];
  $colFile=tv_www().'/api/rh/data/colaboradores.json'; $cols=tv_read_json($colFile); $map=[];
  $arrCols=is_array($cols)?(tv_is_list($cols)?$cols:($cols['colaboradores']??($cols['data']??[]))):[];
  if(is_array($arrCols)) foreach($arrCols as $c){ if(!is_array($c)) continue; $n=tv_norm_txt(tv_pick($c,['nome','colaborador','name'],'')); if($n) $map[$n]=(($c['obra']??true)!==false && ($c['ativo']??true)!==false && ($c['is_obra']??true)!==false); }
  $isObra=function($nome) use ($map){ $k=tv_norm_txt($nome); return array_key_exists($k,$map)?(bool)$map[$k]:true; };
  $scan=function($x) use (&$scan,&$total,&$l,$ym,$isObra){ if(!is_array($x)) return; if(tv_is_list($x)){ foreach($x as $v)$scan($v); return; } $data=(string)tv_pick($x,['data','date','dia','created_at','createdAt'],''); $valor=tv_pick_num($x,['valor','value','total','realizado'],0); $col=tv_pick($x,['colaborador','colaborador_origem','nome'],''); if($valor>0 && $data!=='' && substr($data,0,7)===$ym && $isObra($col)){ $total+=$valor; $l[]=['data'=>$data,'valor'=>$valor,'colaborador'=>$col]; } foreach($x as $v) if(is_array($v)) $scan($v); };
  $scan($j); return ['fonte'=>tv_meta($file),'total_mes'=>round($total,2),'lancamentos'=>$l];
}

function tv_coord_key($s){ $n=tv_norm_txt($s); if(strpos($n,'PABLO')!==false) return 'PABLO'; if(strpos($n,'FABIO')!==false) return 'FABIO'; if(strpos($n,'NICOLAS')!==false) return 'NICOLAS'; return $n; }

function tv_kpi_resumo(){
  $obras=tv_cronogramas_ativos(); $tv=tv_status_obras_ativas(); $comb=tv_combustivel_mes(); $qpi1Info=tv_qpi1_mes();
  $coords=['PABLO'=>true,'FABIO'=>true,'NICOLAS'=>true];
  foreach($obras as $o){ $c=tv_coord_key($o['coordenador']); if($c) $coords[$c]=true; }
  $out=[]; $qpi5=$comb['total_mes']<=5000?100:($comb['total_mes']<=7000?50:0); $qpi1=$qpi1Info['score'];
  foreach(array_keys($coords) as $coord){
    if(!in_array($coord,['PABLO','FABIO','NICOLAS'],true)) continue;
    $cron=array_values(array_filter($obras,function($o) use ($coord){ return tv_coord_key($o['coordenador'])===$coord; }));
    $tvItems=array_values(array_filter($tv['obras'],function($o) use ($coord){ return tv_coord_key($o['coordenador'])===$coord; }));
    $tvOk=array_values(array_filter($tvItems,function($o){ return $o['dias_sem_atualizacao']!==null && $o['dias_sem_atualizacao']<=7; }));
    $cronOk=array_values(array_filter($cron,function($o){ return $o['dias_sem_atualizacao']!==null && $o['dias_sem_atualizacao']<=7; }));
    $qpi2=count($tvItems)?round(count($tvOk)/count($tvItems)*100,2):100;
    $qpi3=100;
    $qpi4=count($cron)?round(count($cronOk)/count($cron)*100,2):100;
    $score=round(($qpi1*.10)+($qpi2*.30)+($qpi3*.25)+($qpi4*.25)+($qpi5*.10),2);
    $out[]=['nome'=>$coord,'percentual'=>$score,'score_ponderado'=>$score,'kpi1'=>$qpi1,'kpi2'=>$qpi2,'kpi3'=>$qpi3,'kpi4'=>$qpi4,'kpi5'=>$qpi5,'obras_tv'=>count($tvItems),'obras'=>count($cron),'cronogramas'=>count($cron),'atualizacoes_no_prazo'=>count($tvOk),'cronogramas_no_prazo'=>count($cronOk),'pendencias'=>['tv'=>array_values(array_filter($tvItems,function($o){return $o['dias_sem_atualizacao']===null || $o['dias_sem_atualizacao']>7;})),'cronograma'=>array_values(array_filter($cron,function($o){return $o['dias_sem_atualizacao']===null || $o['dias_sem_atualizacao']>7;}))]];
  }
  usort($out,function($a,$b){return $b['percentual']<=>$a['percentual'];});
  $media=count($out)?round(array_sum(array_map(function($x){return $x['percentual'];},$out))/count($out),2):0;
  return ['ok'=>true,'gerado_em'=>date('c'),'titulo'=>'Resumo geral dos coordenadores • score ponderado com maior peso nos indicadores individuais','coletivo'=>$media,'combustivel'=>$comb['total_mes'],'qpi1_base'=>$qpi1Info,'pesos'=>['kpi1'=>0.10,'kpi2'=>0.30,'kpi3'=>0.25,'kpi4'=>0.25,'kpi5'=>0.10],'coordenadores'=>$out];
}
?>
