<?php
require_once __DIR__ . '/_tv_helpers.php';
try{
  $res = tv_status_obras_ativas();
  $ok=0; $pend=0;
  foreach($res['obras'] as $o){ if($o['dias_sem_atualizacao']!==null && $o['dias_sem_atualizacao']<=7) $ok++; else $pend++; }
  $res['ok']=true;
  $res['gerado_em']=date('c');
  $res['atualizadas_ate_7_dias']=$ok;
  $res['pendentes_atualizacao']=$pend;
  tv_out($res);
}catch(Throwable $e){ tv_out(['ok'=>false,'erro'=>$e->getMessage(),'linha'=>$e->getLine()],500); }
