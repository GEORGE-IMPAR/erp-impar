<?php
require_once __DIR__ . '/_tv_helpers.php';
try{ tv_out(tv_atividade_dia_resumo(tv_ymd())); }
catch(Throwable $e){ tv_out(['ok'=>false,'erro'=>$e->getMessage(),'linha'=>$e->getLine()],500); }
