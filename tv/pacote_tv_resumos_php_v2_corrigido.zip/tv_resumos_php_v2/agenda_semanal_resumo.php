<?php
require_once __DIR__ . '/_tv_helpers.php';
try{ $semana = isset($_GET['semana']) ? tv_week() : ''; tv_out(tv_agenda_semanal_resumo($semana)); }
catch(Throwable $e){ tv_out(['ok'=>false,'erro'=>$e->getMessage(),'linha'=>$e->getLine()],500); }
