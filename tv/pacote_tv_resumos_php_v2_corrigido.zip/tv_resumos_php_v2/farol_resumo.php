<?php
require_once __DIR__ . '/_tv_helpers.php';
try{
  $obras = tv_cronogramas_ativos();
  $verde=0; $amarelo=0; $vermelho=0;
  foreach($obras as &$o){
    $real=(float)($o['realizado']??0); $prev=(float)($o['previsto']??0);
    if($real >= $prev) { $o['farol']='verde'; $verde++; }
    elseif(($prev-$real) <= 10) { $o['farol']='amarelo'; $amarelo++; }
    else { $o['farol']='vermelho'; $vermelho++; }
  }
  tv_out([
    'ok'=>true,
    'gerado_em'=>date('c'),
    'total_obras'=>count($obras),
    'verde'=>$verde,
    'amarelo'=>$amarelo,
    'vermelho'=>$vermelho,
    'obras'=>$obras
  ]);
}catch(Throwable $e){ tv_out(['ok'=>false,'erro'=>$e->getMessage(),'linha'=>$e->getLine()],500); }
